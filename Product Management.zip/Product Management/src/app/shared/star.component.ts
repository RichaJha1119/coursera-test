import {Component,Input,Output,EventEmitter} from '@angular/core'
import { OnChanges } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({
templateUrl:`./star.component.html`,
styleUrls:['./star.component.css'],
selector:'pm-star'
})

export class StarComponent implements OnChanges{
    starWidth:number;
    @Input() rating:number;

    @Output() ratingClicked:EventEmitter<string>= new EventEmitter<string>();

    ngOnChanges():void{
    this.starWidth=this.rating*86/5;
    }

    onClick():void{
        this.ratingClicked.emit(`The rating ${this.rating} is clicked.`);
    }
}